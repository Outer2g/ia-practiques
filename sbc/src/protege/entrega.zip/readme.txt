Prototipo inicial:
	Esta es una version muy simple del prototipo final.
	En esta versión solo se tiene en cuenta la edad y la masa corporal de la persona pra determinar que ejercicios debe o no debe hacer, es por esta misma razón, que las reglas y las posibilidades son muy pocas hasta el momento. Al tener en cuenta sólo estos dos factores y obviar los posibles problemas de salud y lesiones. Todo usuario podra hacer todo tipo de ejercicio menos dos: Curl con mancuernas y elevaciones de discolas cuales se deciden en funcion de la edad.
	La generacion del horario semanal, es muy simple y sera mejorada para el prototipo final.
	Tambien decide en global la intensidad y el numero de repeticiones, segun la masa corporal y la edad, para el prototipo final estas tendran que depender de más factores, como por ejemplo, el objetivo y problemas de salud.

