package aima.basic;

public class Percept extends ObjectWithDynamicAttributes {

}