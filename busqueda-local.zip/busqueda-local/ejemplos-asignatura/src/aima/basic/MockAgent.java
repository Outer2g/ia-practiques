package aima.basic;

public class MockAgent extends Agent {

}