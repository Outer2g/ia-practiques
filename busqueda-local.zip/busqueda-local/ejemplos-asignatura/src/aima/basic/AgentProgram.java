package aima.basic;

public abstract class AgentProgram {

	public abstract String execute(Percept percept);

}