import aima.search.framework.SuccessorFunction;

import java.util.List;

/**
 * Created by albert on 08/03/16.
 */
public class   DistribFileSystemSuccessorFunction implements SuccessorFunction {
    @Override
    public List getSuccessors(Object state) {
        return null;
    }
}
