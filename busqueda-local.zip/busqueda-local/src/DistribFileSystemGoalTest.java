/**
 * Created by albert on 08/03/16.
 */
import aima.search.framework.GoalTest;

public class DistribFileSystemGoalTest implements GoalTest {
    @Override
    public boolean isGoalState(Object state) {
        return false;
    }
}
